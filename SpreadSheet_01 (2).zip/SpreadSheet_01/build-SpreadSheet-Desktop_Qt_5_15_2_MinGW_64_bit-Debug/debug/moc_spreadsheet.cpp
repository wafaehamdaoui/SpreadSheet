/****************************************************************************
** Meta object code from reading C++ file 'spreadsheet.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../SpreadSheet/spreadsheet.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'spreadsheet.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_SpreadSheet_t {
    QByteArrayData data[17];
    char stringdata0[154];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SpreadSheet_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SpreadSheet_t qt_meta_stringdata_SpreadSheet = {
    {
QT_MOC_LITERAL(0, 0, 11), // "SpreadSheet"
QT_MOC_LITERAL(1, 12, 7), // "NewFile"
QT_MOC_LITERAL(2, 20, 0), // ""
QT_MOC_LITERAL(3, 21, 5), // "close"
QT_MOC_LITERAL(4, 27, 15), // "updateStatusBar"
QT_MOC_LITERAL(5, 43, 8), // "about_me"
QT_MOC_LITERAL(6, 52, 8), // "about_qt"
QT_MOC_LITERAL(7, 61, 10), // "goCellSlot"
QT_MOC_LITERAL(8, 72, 13), // "find_function"
QT_MOC_LITERAL(9, 86, 8), // "saveSlot"
QT_MOC_LITERAL(10, 95, 8), // "openFile"
QT_MOC_LITERAL(11, 104, 15), // "OpenRecentFiles"
QT_MOC_LITERAL(12, 120, 11), // "OpenCsvFile"
QT_MOC_LITERAL(13, 132, 4), // "Copy"
QT_MOC_LITERAL(14, 137, 5), // "Paste"
QT_MOC_LITERAL(15, 143, 6), // "Delete"
QT_MOC_LITERAL(16, 150, 3) // "Cut"

    },
    "SpreadSheet\0NewFile\0\0close\0updateStatusBar\0"
    "about_me\0about_qt\0goCellSlot\0find_function\0"
    "saveSlot\0openFile\0OpenRecentFiles\0"
    "OpenCsvFile\0Copy\0Paste\0Delete\0Cut"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SpreadSheet[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   89,    2, 0x08 /* Private */,
       3,    0,   90,    2, 0x08 /* Private */,
       4,    2,   91,    2, 0x08 /* Private */,
       5,    0,   96,    2, 0x08 /* Private */,
       6,    0,   97,    2, 0x08 /* Private */,
       7,    0,   98,    2, 0x08 /* Private */,
       8,    0,   99,    2, 0x08 /* Private */,
       9,    0,  100,    2, 0x08 /* Private */,
      10,    0,  101,    2, 0x08 /* Private */,
      11,    0,  102,    2, 0x08 /* Private */,
      12,    0,  103,    2, 0x08 /* Private */,
      13,    0,  104,    2, 0x08 /* Private */,
      14,    0,  105,    2, 0x08 /* Private */,
      15,    0,  106,    2, 0x08 /* Private */,
      16,    0,  107,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void SpreadSheet::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<SpreadSheet *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->NewFile(); break;
        case 1: _t->close(); break;
        case 2: _t->updateStatusBar((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 3: _t->about_me(); break;
        case 4: _t->about_qt(); break;
        case 5: _t->goCellSlot(); break;
        case 6: _t->find_function(); break;
        case 7: _t->saveSlot(); break;
        case 8: _t->openFile(); break;
        case 9: _t->OpenRecentFiles(); break;
        case 10: _t->OpenCsvFile(); break;
        case 11: _t->Copy(); break;
        case 12: _t->Paste(); break;
        case 13: _t->Delete(); break;
        case 14: _t->Cut(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject SpreadSheet::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_SpreadSheet.data,
    qt_meta_data_SpreadSheet,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *SpreadSheet::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SpreadSheet::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_SpreadSheet.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int SpreadSheet::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 15;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
