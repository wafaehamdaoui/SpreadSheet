#include "spreadsheet.h"
#include <QPixmap>
#include <QMenuBar>
#include <QToolBar>
#include <QApplication>
#include <QMessageBox>
#include <dialog.h>
#include <find.h>
#include <QFile>
#include <QTextStream>
#include <QFileDialog>
#include <QSettings>


SpreadSheet::SpreadSheet(QWidget *parent)
    : QMainWindow(parent)
{
    //Seting the spreadsheet

    setupMainWidget();

    // Creaeting Actions
    createActions();

    // Creating Menus
    createMenus();


    //Creating the tool bar
    createToolBars();

    //making the connexions
    makeConnexions();


    //Creating the labels for the status bar (should be in its proper function)
    cellLocation = new QLabel("(1, 1)");
    cellFormula = new QLabel("");
    statusBar()->addPermanentWidget(cellLocation);
    statusBar()->addPermanentWidget(cellFormula);

    //vertival labels
    QStringList labels;
    for(auto letter='A'; letter<= 'Z'; letter++){
        labels <<QString(letter);
    }
    spreadsheet->setVerticalHeaderLabels(labels);
}

void SpreadSheet::setupMainWidget()
{
    spreadsheet = new QTableWidget;
    spreadsheet->setRowCount(100);
    spreadsheet->setColumnCount(100);
    setCentralWidget(spreadsheet);

}

SpreadSheet::~SpreadSheet()
{
    delete spreadsheet;

    //  Actions
    delete  newFile;
    delete  open;
    delete  save;
    delete  saveAs;
    delete  exit;
    delete cut;
    delete copy;
    delete paste;
    delete deleteAction;
    delete find;
    delete row;
    delete Column;
    delete all;
    delete goCell;
    delete recalculate;
    delete sort;
    delete showGrid;
    delete auto_recalculate;
    delete about;
    delete aboutQt;

    //  Menus
    delete FileMenu;
    delete editMenu;
    delete toolsMenu;
    delete optionsMenu;
    delete helpMenu;
}

void SpreadSheet::createActions()
{
    // New File
   QPixmap newIcon(":/New.bmp");
   newFile = new QAction(newIcon, "&New", this);
   newFile->setShortcut(tr("Ctrl+N"));


    // open file
   QPixmap openIcon(":/Open.bmp");
   open = new QAction(openIcon,"&Open", this);
   open->setShortcut(tr("Ctrl+O"));

   // open file
  QPixmap csvIcon(":/csv.jfif");
  opencsv = new QAction(csvIcon,"&Open csv", this);
  opencsv->setShortcut(tr("Ctrl+O+C"));

    //  save file
   QPixmap saveIcon(":/Save.bmp");
   save = new QAction(saveIcon,"&Save", this);
   save->setShortcut(tr("Ctrl+S"));

    //  open file
   saveAs = new QAction("save &As", this);


    // open file
   QPixmap cutIcon(":/Cut.bmp");
   cut = new QAction(newIcon, "Cu&t", this);
   cut->setShortcut(tr("Ctrl+X"));

   // Cut menu
   QPixmap copyIcon(":/Copy.bmp");
   copy = new QAction(copyIcon,"&Copy", this);
   copy->setShortcut(tr("Ctrl+C"));

   QPixmap pasteIcon(":/Paste.bmp");
   paste = new QAction(pasteIcon,"&Paste", this);
   paste->setShortcut(tr("Ctrl+V"));

   QPixmap deleteIcon(":/DeleteSticky.bmp");
   deleteAction = new QAction(deleteIcon,"&Delete", this);
   deleteAction->setShortcut(tr("Ctrl+D"));


   row  = new QAction("&Row", this);
   Column = new QAction("&Column", this);
   all = new QAction("&All", this);
   all->setShortcut(tr("Ctrl+A"));



   QPixmap findIcon(":/search_icon.png");
   find= new QAction(findIcon, "&Find", this);
   find->setShortcut(tr("Ctrl+F"));

   QPixmap goCellIcon(":/go_to_icon.png");
   goCell = new QAction( goCellIcon, "&Go to Cell", this);
   deleteAction->setShortcut(tr("f5"));


   recalculate = new QAction("&Recalculate",this);
   recalculate->setShortcut(tr("F9"));


   sort = new QAction("&Sort");



   showGrid = new QAction("&Show Grid");
   showGrid->setCheckable(true);
   showGrid->setChecked(spreadsheet->showGrid());

   auto_recalculate = new QAction("&Auto-recalculate");
   auto_recalculate->setCheckable(true);
   auto_recalculate->setChecked(true);

   //recent files

   QPixmap recentIcon(":/th.jfif");
//   RecentFile = new (recentIcon,"&Recent Files");
//   recentFile->setShortcut(tr("Ctrl+R"));
   for (int i = 0; i < MaxRecentFiles; ++i){
       if (i < recentFiles.count()){
       recentFileActs[i]= new QAction;}
   }

   about =  new QAction("&About");
   aboutQt = new QAction("About &Qt");

    // exit
   QPixmap exitIcon(":/quit_icon.png");
   exit = new QAction(exitIcon,"E&xit", this);
   exit->setShortcut(tr("Ctrl+Q"));
   //recent files


}

void SpreadSheet::close()
{

    auto reply = QMessageBox::question(this, "Exit",
                                       "Do you really want to quit?");
    if(reply == QMessageBox::Yes)
        qApp->exit();
}

void SpreadSheet::createMenus()
{
    // --------  File menu -------//
    FileMenu = menuBar()->addMenu("&File");
    FileMenu->addAction(newFile);
    FileMenu->addAction(open);
    FileMenu->addAction(opencsv);
//    FileMenu->addAction(recentFile);
//    separatorAction = FileMenu->addSeparator();
//        for (int i = 0; i < MaxRecentFiles; ++i){
//            FileMenu->addAction(recentFileActions[i]);
//        }
    FileMenu->addAction(save);
    FileMenu->addAction(saveAs);
    FileMenu->addAction(exit);

    RecentFile = FileMenu->addSeparator();
    for (int i = 0; i < MaxRecentFiles; ++i){
        if (i < recentFiles.count()){
        FileMenu->addAction(recentFileActs[i]);}
    }
    updateRecentFile();

    // Edit menu
    editMenu = menuBar()->addMenu("&Edit");
    editMenu->addAction(cut);
    editMenu->addAction(copy);
    editMenu->addAction(paste);
    editMenu->addAction(deleteAction);
    editMenu->addSeparator();
    auto select = editMenu->addMenu("&Select");
    select->addAction(row);
    select->addAction(Column);
    select->addAction(all);

    editMenu->addAction(find);
    editMenu->addAction(goCell);



    // Toosl menu
    toolsMenu = menuBar()->addMenu("&Tools");
    toolsMenu->addAction(recalculate);
    toolsMenu->addAction(sort);



    //Optins menus
    optionsMenu = menuBar()->addMenu("&Options");
    optionsMenu->addAction(showGrid);
    optionsMenu->addAction(auto_recalculate);


    // Help menu
    helpMenu = menuBar()->addMenu("&Help");
    helpMenu->addAction(about);
    helpMenu->addAction(aboutQt);
}

void SpreadSheet::createToolBars()
{

    //Crer une bare d'outils
    auto toolbar1 = addToolBar("File");


    //Ajouter des actions acette bar
    toolbar1->addAction(newFile);
    toolbar1->addAction(save);
    toolbar1->addSeparator();
    toolbar1->addAction(exit);


    //Creer une autre tool bar
    auto toolbar2  = addToolBar("ToolS");
    toolbar2->addAction(goCell);
}

void SpreadSheet::NewFile()
{
    SpreadSheet *other = new SpreadSheet;
    other->show();
}

void SpreadSheet::updateStatusBar(int row, int col)
{
    QString cell{"(%0, %1)"};
   cellLocation->setText(cell.arg(row+1).arg(col+1));

}

void SpreadSheet::goCellSlot()
 {
    //bar d'outil
    statusBar()->showMessage("Go Dialog",10000);

     //Creating the dialog
     Dialog D;

     //Executing the dialog and storing the user response
     auto reply = D.exec();

     //Checking if the dialog is accepted
     if(reply == Dialog::Accepted)
     {

         //Getting the cell text
         auto cell = D.cell();

         //letter distance
         int row = cell[0].toLatin1() - 'A';
         cell.remove(0,1);

         //second coordinate
         int col =  cell.toInt();


         //changing the current cell
         spreadsheet->setCurrentCell(row, col-1);
     }
}

void SpreadSheet::find_function(){

    //bar d'outil
    statusBar()->showMessage("Searching",10000);

     //Creating the dialog
     Find D;

     //Executing the dialog and storing the user response
     auto reply = D.exec();

     //Checking if the dialog is accepted
     if(reply == Find::Accepted)
     {

         //Getting the search text
         auto Find = D.find();

         for(int row=spreadsheet->rowCount()-1; row>=0; row--){
             for(int col=spreadsheet->columnCount()-1;col>=0;col--){
                 if(spreadsheet->item(row,col)){
                     if(spreadsheet->item(row,col)->text().contains(Find)){
                         spreadsheet->setCurrentCell(row, col);
                    }
                 }
             }
         }
     }


}


    void SpreadSheet::saveContent(QString filename) const
    {

        //Gettign a pointer on the file
        QFile file(filename);

        //Openign the file
        if(file.open(QIODevice::WriteOnly))  //Opening the file in writing mode
        {
            //Initiating a stream using the file
            QTextStream out(&file);

            //loop to save all the content
            for(int i=0; i < spreadsheet->rowCount();i++)
                for(int j=0; j < spreadsheet->columnCount(); j++)
                {
                    auto cell = spreadsheet->item(i, j);

                    //Cecking if the cell is non empty
                    if(cell)
                    out << cell->row() << ", "<< cell->column() << ", " << cell->text() << endl;
                }

        }
        file.close();
}

    bool SpreadSheet::readFile(const QString &fileName)
    {
        QFile file(fileName);
        if (!file.open(QIODevice::ReadOnly)) {
            QMessageBox::warning(this, tr("Spreadsheet"),
                                 tr("Cannot read file %1:\n%2.")
                                 .arg(file.fileName())
                                 .arg(file.errorString()));
            return false;
        }

        QDataStream in(&file);
        in.setVersion(QDataStream::Qt_4_3);


    }


    void SpreadSheet::loadFile(const QString &fileName)

    {
        if (SpreadSheet::readFile(fileName)) {
         setCurrentFile(fileName);
         statusBar()->showMessage(tr("File loaded"), 2000);
         } else {
         statusBar()->showMessage(tr("Loading canceled"), 2000);
         }

           setCurrentFile(fileName);
           statusBar()->showMessage(tr("File loaded"), 2000);
        }

//        QFile file(fileName);
//           if (!file.open(QFile::ReadOnly)) {
//               QMessageBox::warning(this, tr("Application"),
//                                    tr("Cannot read file %1:\n%2.")
//                                    .arg(QDir::toNativeSeparators(fileName), file.errorString()));
//               return;
//           }
//           QTextStream in(&file);
//           QString text = in.readAll();
//           //  Copy text in the string
//           for(int i=0; i < spreadsheet->rowCount();i++)
//               for(int j=0; j < spreadsheet->columnCount(); j++)
//               {
//                   auto cell = spreadsheet->item(i, j);

//                   spreadsheet->setItem(text[0].t(),text[1],text[2]);
//               }
//            QString fileName = QFileDialog::getOpenFileName(this, ("Open File"));
//            QString data;
//            QFile file(fileName);


//            QStringList rowOfData;
//            QStringList columnData;
//            data.clear();
//            rowOfData.clear();
//            columnData.clear();

//            if (file.open(QFile::ReadOnly))
//            {
//                data = file.readAll();
//                rowOfData = data.split("\n");           //Value on each row
//                file.close();
//            }

//            for (int x = 0; x < rowOfData.size(); x++)  //rowOfData.size() gives the number of row
//            {
//                columnData = rowOfData.at(x).split(",");   //Number of collumn

////               int r=columnData.size();
//                for (int y = 0; y < columnData.size()-2; y++)
////                {
//                    spreadsheet->setItem(columnData[y].toInt(),columnData[y+1].toInt(),new QTableWidgetItem(columnData[y+2]));

//            }

//           statusBar()->showMessage(tr("File loaded"), 2000);

//    }

void SpreadSheet::openFile()
           {

                   QString fileName = QFileDialog::getOpenFileName(this, tr("Open Spreadsheet"),
                                                                   ".",
                                                                   tr("Spreadsheet files (*.sp)\n"
                                                                      "Comma-separated values files (*.csv)\n"
                                                                      "Lotus 1-2-3 files (*.wk1 *.wks)"));
                   if(!fileName.isEmpty()){
                       loadFile(fileName);
                   }

           }

void SpreadSheet::saveSlot()
    {
        //Creating a file dialog to choose a file graphically
        auto dialog = new QFileDialog(this);

        //Check if the current file has a name or not
        if(currentFile == "")
        {
           currentFile = dialog->getSaveFileName(this,"choose your file");

           //Update the window title with the file name
           setWindowTitle(currentFile);
        }

       //If we have a name simply save the content
       if( currentFile != "")
       {
               saveContent(currentFile);
       }
//       recentFiles.append(currentFile);
//       if(recentFiles.count()>MaxRecentFiles){
//           recentFiles.removeLast();
//       }
    }
void SpreadSheet::OpenCsvFile(){
    QString fileName = QFileDialog::getOpenFileName(this, ("Open File"));
    QString data;
    QFile file(fileName);


    QStringList rowOfData;
    QStringList columnData;
    data.clear();
    rowOfData.clear();
    columnData.clear();

    if (file.open(QFile::ReadOnly))
    {
        data = file.readAll();
        rowOfData = data.split("\n");           //Value on each row
        file.close();
    }

    for (int x = 0; x < rowOfData.size(); x++)  //rowOfData.size() gives the number of row
    {
        columnData = rowOfData.at(x).split(",");   //Number of collumn

//               int r=columnData.size();
        for (int y = 0; y < columnData.size()-2; y++)
//                {
            spreadsheet->setItem(columnData[y].toInt(),columnData[y+1].toInt(),new QTableWidgetItem(columnData[y+2]));

    }

   statusBar()->showMessage(tr("File loaded"), 2000);

}


void SpreadSheet::setCurrentFile(const QString &fileName)
{
    currentFile = fileName;
    setWindowFilePath(currentFile);

    QSettings settings;
    QStringList files = settings.value("recentFileList").toStringList();
    files.removeAll(fileName);
    files.prepend(fileName);
    while (files.size() > MaxRecentFiles)
        files.removeLast();

    settings.setValue("recentFileList", files);

    foreach (QWidget *widget, QApplication::topLevelWidgets()) {
        SpreadSheet *mainWin = qobject_cast<SpreadSheet *>(widget);
        if (mainWin)
            mainWin->updateRecentFile();
    }
}

void SpreadSheet::updateRecentFile()
{
    QSettings settings;
    QStringList files = settings.value("recentFileList").toStringList();

    int numRecentFiles = qMin(files.size(), (int)MaxRecentFiles);

    for (int i = 0; i < numRecentFiles; ++i) {
        QString text = tr("&%1 %2").arg(i + 1).arg(QFileInfo(files[i]).fileName());
        recentFileActs[i]->setText(text);
        recentFileActs[i]->setData(files[i]);
        recentFileActs[i]->setVisible(true);
    }
    for (int j = numRecentFiles; j < numRecentFiles; ++j)
        recentFileActs[j]->setVisible(false);

      RecentFile->setVisible(numRecentFiles > 0);
}

void SpreadSheet::OpenRecentFiles()
{
    QAction *action = qobject_cast<QAction *>(sender());
    if (action)
        loadFile(action->data().toString());
}



void SpreadSheet::about_me(){
    QMessageBox::about(this, "about me","I'm trying to create a spreadSheet applicaton ");
}

void SpreadSheet::about_qt(){
    QMessageBox::aboutQt(this, "about Qt");
}
void SpreadSheet::Copy(){
    Pastetxt = new QTableWidgetItem(spreadsheet->currentItem()->text());
//    i=spreadsheet->currentRow();
//    j=spreadsheet->currentColumn();
}
void SpreadSheet::Paste(){
    i=spreadsheet->currentRow();
    j=spreadsheet->currentColumn();
    spreadsheet->setItem(i,j,Pastetxt);
}

void SpreadSheet::Delete(){
    i=spreadsheet->currentRow();
    j=spreadsheet->currentColumn();
    spreadsheet->item(i,j)->setText("");
}

void SpreadSheet::Cut(){
    Copy();
    Delete();
}

void SpreadSheet::makeConnexions()
{
    //Connection for new file action
    connect(newFile, &QAction::triggered,
            this, &SpreadSheet::NewFile);


   //  Connexion for the  select all/row/column action
   connect(all, &QAction::triggered,
           spreadsheet, &QTableWidget::selectAll);

   connect(row, &QAction::triggered,
           spreadsheet, &QTableWidget::selectRow);

   connect(Column, &QAction::triggered,
           spreadsheet, &QTableWidget::selectColumn);




   // Connection for the  show grid
   connect(showGrid, &QAction::triggered,
           spreadsheet, &QTableWidget::setShowGrid);

   //Connection for the exit button
   connect(exit, &QAction::triggered, this, &SpreadSheet::close);


   //connectting the chane of any element in the spreadsheet with the update status bar
   connect(spreadsheet, &QTableWidget::cellClicked, this,  &SpreadSheet::updateStatusBar);

   // Connection for about
   connect(about, &QAction::triggered, this,&SpreadSheet::about_me);

   // Connection for the  aboutQt
   connect(aboutQt, &QAction::triggered, this,&SpreadSheet::about_qt);

   //Connextion between the gocell action and the gocell slot
   connect(goCell, &QAction::triggered, this, &SpreadSheet::goCellSlot);

   //Connextion between the find action and the find_funtion slot
   connect(find, &QAction::triggered, this, &SpreadSheet::find_function);

   //Connexion for the saveFile
      connect(save, &QAction::triggered, this, &SpreadSheet::saveSlot);


      //Connexion for the openCsvFile
         connect(opencsv, &QAction::triggered, this, &SpreadSheet::OpenCsvFile);

         //Connexion for the open
                  connect(open, &QAction::triggered, this, &SpreadSheet::openFile);


         //connexion for recentFiles
         for (int i = 0; i < MaxRecentFiles; ++i) {
             if (i < recentFiles.count()){
                connect(recentFileActs[i], SIGNAL(triggered()),
                         this, SLOT(openRecentFile()));}
             }
//         connect(recentFile, &QAction::triggered, this, &SpreadSheet::RecentFiles);

         //connexion for copy action
         connect(copy, &QAction::triggered, this, &SpreadSheet::Copy);

         //connexion for paste action
         connect(paste, &QAction::triggered, this, &SpreadSheet::Paste);

         //connexion for delete action
         connect(deleteAction, &QAction::triggered, this, &SpreadSheet::Delete);

         //connexion for cut action
         connect(cut, &QAction::triggered, this, &SpreadSheet::Cut);
}
