#ifndef SPREADSHEET_H
#define SPREADSHEET_H

#include <QMainWindow>
#include <QTableWidget>
#include <QAction>
#include <QMenu>
#include <QToolBar>
#include <QLabel>
#include <QStatusBar>
#include <QFile>
#include <QList>

class SpreadSheet : public QMainWindow
{
    Q_OBJECT

public:
    SpreadSheet(QWidget *parent = nullptr);
    ~SpreadSheet();

protected:
    void setupMainWidget();
    void createActions();
    void createMenus();
    void createToolBars();
    void makeConnexions();
    void saveContent(QString filename)const;
    void updateRecentFile();
    void setCurrentFile(const QString &fileName);
    void loadFile(const QString &fileName);
    bool readFile(const QString &fileName);

private slots:
    void NewFile();
    void close();
    void updateStatusBar(int, int); //Respond for the call changed
    void about_me();
    void about_qt();
    void goCellSlot();
    void find_function();
    void saveSlot();
    void openFile();
    void OpenRecentFiles();
    void OpenCsvFile();
    void Copy();
    void Paste();
    void Delete();
    void Cut();

 //Pointers
private:
     enum { MaxRecentFiles = 5 };
    //  Main Widget
    QTableWidget *spreadsheet;
    //Actions
    QAction * newFile;
    QAction * open;
    QAction * opencsv;
    QAction * save;
    QAction * saveAs;
    QAction * exit;
    QAction *load;
    QAction *cut;
    QAction *copy;
    QAction *paste;
    QAction *deleteAction;
    QAction *find;
    QAction *row;
    QAction *Column;
    QAction *all;
    QAction *goCell;
    QAction *recalculate;
    QAction *sort;
    QAction *showGrid;
    QAction *auto_recalculate;
    QAction *about;
    QAction *aboutQt;
    QAction *recentFileActs[MaxRecentFiles];
    QAction *separatorAction;


    //Menus
    QMenu *FileMenu;
    QMenu *editMenu;
    QMenu *toolsMenu;
    QMenu *optionsMenu;
    QMenu *helpMenu;
    QAction *RecentFile;


    // Widget pour la bare d'etat
    QLabel *cellLocation;  //position de la cellule active
    QLabel *cellFormula;   // Formuel de la cellue active

    //file
    QString currentFile = "";
    QString recentFileActionList[4] ;
    QStringList recentFiles;


    //copy & paste
    int i,j;
    QTableWidgetItem *Pastetxt;


};

#endif // SPREADSHEET_H
