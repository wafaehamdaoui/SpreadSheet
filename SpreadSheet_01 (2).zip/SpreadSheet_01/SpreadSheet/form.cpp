#include "form.h"
#include "ui_form.h"
#include <QRegExp>
#include <QRegExpValidator>

Form::Form(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Form)
{
    ui->setupUi(this);
    //Validating the regular expression
     QRegExp regCell{"[A-Z][1-9][0-9]{0,2}"};

     //Validating the regular expression
     ui->lineEdit->setValidator(new QRegExpValidator(regCell));

}

Form::~Form()
{
    delete ui;
}




QString Form::cell() const
     {
         return ui->lineEdit->text();
     }
