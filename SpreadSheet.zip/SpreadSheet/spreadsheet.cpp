#include "spreadsheet.h"
#include "ui_spreadsheet.h"
#include <QAction>
#include <QApplication>
#include <QMainWindow>

SpreadSheet::SpreadSheet(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::SpreadSheet)
{
    ui->setupUi(this);
}

SpreadSheet::~SpreadSheet()
{
    delete ui;
}
//Function to create all the widgets
void SpreadSheet::createActions()
{
   //Create the icon
   QPixmap quitIcon(":/quit_icon.png");

   // Create the action
   quit = new QAction(quitIcon, "&Quit", this);


    //Optional set the shortcut
    quit->setShortcut(tr("Ctrl+Q"));

   connect(quit, &QAction::triggered,
   qApp, &QApplication::exit);

}
void SpreadSheet::createMenues()
{
    //Creating the menu
    fileMenu = new QMenu("&File", this);
    menuBar()->addMenu(fileMenu);

    fileMenu->addAction(newFile);
    fileMenu->addAction(openFile);
    fileMenu->addSeparator();
    fileMenu->addAction(quit);


    //Edit menu
    editMenu = new QMenu("&Edit");
    menuBar()->addMenu(editMenu);


    //Tools Menu
    toolsMenu = new QMenu("&Tools");
    menuBar()->addMenu(toolsMenu);
    auto selectMenu = toolsMenu->addMenu("Select");
    selectMenu->addAction(selectRow);
    selectMenu->addAction(selectColumn);


    //options
    optionsMenu = new QMenu("&Options");
    menuBar()->addMenu(optionsMenu);
    optionsMenu->addAction(showGrid);

    //help
    helpMenu = new QMenu("&Help");
    helpMenu->addAction(about);
    menuBar()->addMenu(helpMenu);

}
void MainWindow::createToolBars()
{
    toolbar = addToolBar("tr(&Main toolbar)");
    //adding the actions
    toolbar->addAction(newfile);
    toolbar->addAction(openfile);

    toolbar->addSeparator(); // Adding a separator

    toolbar->addAction(quit);
}
