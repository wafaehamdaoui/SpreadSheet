#ifndef SPREADSHEET_H
#define SPREADSHEET_H

#include <QMainWindow>
#include <QMenu>
#include <QTabWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class SpreadSheet; }
QT_END_NAMESPACE

class SpreadSheet : public QMainWindow
{
    Q_OBJECT

public:
    SpreadSheet(QWidget *parent = nullptr);
    ~SpreadSheet();

private:  //private method
   void createActions();   //Function to create all the actions
   void createMenues();
   void createToolBars();

private:
QAction *newFile;      //Action to open a new file
QAction *openFile;     //Action to open a new file
QAction *saveFile;     // Save the file
QAction *quit;         //Operation close
QAction *about;        //About the application
QAction *selectRow;
QAction *selectColumn;
QAction *showGrid;
QMenu *fileMenu;
QMenu *editMenu;
QMenu *toolsMenu;
QMenu *optionsMenu;
QMenu *helpMenu;


private:
    Ui::SpreadSheet *ui;
};
#endif // SPREADSHEET_H
